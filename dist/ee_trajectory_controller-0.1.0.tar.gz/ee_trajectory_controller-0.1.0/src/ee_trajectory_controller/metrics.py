from ee_trajectory_controller import Pose, Twist, trajectory, trajectoryStep, controllerConfig
from ee_trajectory_controller import projectObjectState
from ee_trajectory_controller import computeSingleDeltaTwist, computeDeltaTwists

import numpy as np
from ee_trajectory_controller import integratePosition, integrateRotation, findRotVec, errorRotVec
import matplotlib.pyplot as plt
from numpy.typing import NDArray
from scipy.spatial.transform import Rotation



def computeMetrics(t: trajectory, targetPose: Pose, settlingTimeWindow: float):
    
    data = t.returnData()

    object_positions = data['object_positions']  # Moving object positions
    object_rotations = data['object_rotations']  # Moving object rotations
    
    
    targetPosition = targetPose.position
    targetRotation = targetPose.rotation
    
    
    time = data['time']
    dt = time[1] - time[0]

    eePositions = data['ee_positions']
    eeRotations = data['ee_rotations']
    
    #absolute position errors
    positionErrors = eePositions - object_positions
    positionErrorMagnitudes = np.linalg.norm(positionErrors, axis = 1)
    
    rotationErrorMagnitudes = []
    for eeRot, objRot in zip(eeRotations, object_rotations):
        #rot_error = np.matmul(eeRot.T, objRot)
        #errVec = Rotation.from_matrix(rot_error).as_rotvec()
        #errVecMagnitude = np.linalg.norm(errVec)
        errVecMagnitude = np.linalg.norm(errorRotVec(eeRot, objRot))
        rotationErrorMagnitudes.append(errVecMagnitude)

    rotationErrorMagnitudes = np.asarray(rotationErrorMagnitudes)
    

    positionResponseMagnitudes = np.linalg.norm(eePositions, axis=1 )
    targetPositionMagnitude = np.linalg.norm(targetPose.position)
    

    posTarget10 = 0.1 * targetPositionMagnitude
    posTarget90 = 0.9 * targetPositionMagnitude
    
    pos_rise_time = None
    pose_start_time = None
    
    for element in positionErrorMagnitudes:
        if element > posTarget10:
            pose_start_time = element
            break
                
    for element in positionErrorMagnitudes:
        if element > posTarget90:
            pose_rise_time = element
            break

    windowOffset = int(settlingTimeWindow/dt)
    pos_settling_threshold = 0.02 * targetPositionMagnitude
    pos_settling_time = None

    for index in range(0, len(positionErrorMagnitudes) - windowOffset ):
        window_errors = positionErrorMagnitudes[index:index+windowOffset]
        if np.all(window_errors <= pos_settling_threshold):
            pos_settling_time = time[index]

    max_pos_response = np.max(positionResponseMagnitudes)
    pos_overshoot = ((max_pos_response - targetPositionMagnitude)/targetPositionMagnitude) * 100

    rot_settling_threshold = 0.02  # 2% of 1 radian ≈ 0.02 rad ≈ 1.15 degrees
    rot_settling_time = None
    
    for i in range(len(rotationErrorMagnitudes) - windowOffset):
        window_errors = rotationErrorMagnitudes[i:i+windowOffset]
        if np.all(window_errors <= rot_settling_threshold):
            rot_settling_time = time[i]
            break           

    max_rot_error = np.max(rotationErrorMagnitudes)
    initial_rot_error = rotationErrorMagnitudes[0]
    rot_overshoot = ((max_rot_error - initial_rot_error) / initial_rot_error) * 100 if initial_rot_error > 0 else 0.0
   

    return {
        'position': {
            'rise_time': pos_rise_time,
            'settling_time': pos_settling_time,
            'overshoot_percent': pos_overshoot,
            'steady_state_error': positionErrorMagnitudes[-1],
            'max_error': np.max(positionErrorMagnitudes),
        },
        'rotation': {
            'settling_time': rot_settling_time,
            'overshoot_percent': rot_overshoot,
            'steady_state_error': rotationErrorMagnitudes[-1],
            'max_error': max_rot_error,
        }
    }

    
def plotMetrics(t: trajectory, target_pose: Pose, metrics=None):
    data = t.returnData()
    
    time = data['time']
    ee_positions = data['ee_positions']
    object_positions = data['object_positions']
    
    

    # Compute errors
    position_errors = object_positions - ee_positions
    position_error_magnitudes = np.linalg.norm(position_errors, axis=1)
    
    # Compute rotation errors
    rotation_error_magnitudes = []
    for ee_rot, objRotation in zip(data['ee_rotations'], data['object_rotations']):
        rot_error = np.matmul(ee_rot.T, objRotation)
        err_vec = Rotation.from_matrix(rot_error).as_rotvec()
        rotation_error_magnitudes.append(np.linalg.norm(err_vec))
    rotation_error_magnitudes = np.array(rotation_error_magnitudes)
    
    fig, axes = plt.subplots(2, 3, figsize=(12, 10))
    
    ## Position tracking
    #ax = axes[0, 0]
    #ax.plot(time, ee_positions[:, 0], label='EE X', linewidth=2)
    #ax.plot(time, ee_positions[:, 1], label='EE Y', linewidth=2)
    #ax.plot(time, ee_positions[:, 2], label='EE Z', linewidth=2)
    #ax.plot(time, object_positions[:,0], color='r', linestyle='--', alpha=0.7, label='Target X')
    #ax.plot(time, object_positions[:,1], color='g', linestyle='--', alpha=0.7, label='Target Y')
    #ax.plot(time, object_positions[:,2], color='b', linestyle='--', alpha=0.7, label='Target Z')
    #ax.set_xlabel('Time (s)')
    #ax.set_ylabel('Position (m)')
    #ax.set_title('Position Response')
    #ax.legend()
    #ax.grid(True)
    #
    ## Position error
    #ax = axes[0, 1]
    #ax.plot(time, position_error_magnitudes, 'r-', linewidth=2)
    #if metrics and metrics['position']['settling_time']:
    #    ax.axvline(metrics['position']['settling_time'], color='g', linestyle='--', label='Settling time')
    #ax.set_xlabel('Time (s)')
    #ax.set_ylabel('Position Error (m)')
    #ax.set_title('Position Error')
    #ax.legend()
    #ax.grid(True)
    #
    ## Rotation error
    #ax = axes[1, 0]
    #ax.plot(time, rotation_error_magnitudes, 'b-', linewidth=2)
    #if metrics and metrics['rotation']['settling_time']:
    #    ax.axvline(metrics['rotation']['settling_time'], color='g', linestyle='--', label='Settling time')
    #ax.set_xlabel('Time (s)')
    #ax.set_ylabel('Rotation Error (rad)')
    #ax.set_title('Rotation Error')
    #ax.legend()
    #ax.grid(True)
    #
    ## Velocities
    #ax = axes[1, 1]
    #ax.plot(time, data['ee_linear_velocities'][:, 0], label='Vx', linewidth=2)
    #ax.plot(time, data['ee_linear_velocities'][:, 1], label='Vy', linewidth=2)
    #ax.plot(time, data['ee_linear_velocities'][:, 2], label='Vz', linewidth=2)
    #ax.set_xlabel('Time (s)')
    #ax.set_ylabel('Velocity (m/s)')
    #ax.set_title('EE Linear Velocities')
    #ax.legend()
    #ax.grid(True)
    

    # 1. Position Response
    ax = axes[0, 0]
    ax.plot(time, ee_positions[:, 0], label='EE X', linewidth=2, color='red')
    ax.plot(time, ee_positions[:, 1], label='EE Y', linewidth=2, color='green')
    ax.plot(time, ee_positions[:, 2], label='EE Z', linewidth=2, color='blue')
    ax.plot(time, object_positions[:, 0], '--', color='darkred', alpha=0.7, label='Target X', linewidth=2)
    ax.plot(time, object_positions[:, 1], '--', color='darkgreen', alpha=0.7, label='Target Y', linewidth=2)
    ax.plot(time, object_positions[:, 2], '--', color='darkblue', alpha=0.7, label='Target Z', linewidth=2)
    ax.set_xlabel('Time (s)')
    ax.set_ylabel('Position (m)')
    ax.set_title('Position Response')
    ax.legend()
    ax.grid()
    
    # 2. Position Error
    ax = axes[0, 1]
    ax.plot(time, position_error_magnitudes, 'r-', linewidth=2)
    if metrics and metrics['position']['settling_time']:
        ax.axvline(metrics['position']['settling_time'], color='g', linestyle='--', label='Settling time')
    ax.set_xlabel('Time (s)')
    ax.set_ylabel('Position Error (m)')
    ax.set_title('Position Error')
    ax.legend()
    ax.grid(True)
    
    # 3. Rotation Error
    ax = axes[0, 2]
    ax.plot(time, rotation_error_magnitudes, 'b-', linewidth=2)
    if metrics and metrics['rotation']['settling_time']:
        ax.axvline(metrics['rotation']['settling_time'], color='g', linestyle='--', label='Settling time')
    ax.set_xlabel('Time (s)')
    ax.set_ylabel('Rotation Error (rad)')
    ax.set_title('Rotation Error')
    ax.legend()
    ax.grid(True)
    
    # Compute rotation errors
    rotation_error_magnitudes = []
    ee_rotvecs = []  # For rotational response plot
    obj_rotvecs = []  # For rotational response plot
    for ee_rot, objRotation in zip(data['ee_rotations'], data['object_rotations']):
        rot_error = np.matmul(ee_rot.T, objRotation)
        err_vec = Rotation.from_matrix(rot_error).as_rotvec()
        rotation_error_magnitudes.append(np.linalg.norm(err_vec))
        
        # Extract rotation vectors for response plot
        ee_rotvec = Rotation.from_matrix(ee_rot).as_rotvec()
        obj_rotvec = Rotation.from_matrix(objRotation).as_rotvec()
        ee_rotvecs.append(ee_rotvec)
        obj_rotvecs.append(obj_rotvec)

    rotation_error_magnitudes = np.array(rotation_error_magnitudes)
    ee_rotvecs = np.array(ee_rotvecs)
    obj_rotvecs = np.array(obj_rotvecs)

    
    # 4. Rotational Response (rotation vector components)
    ax = axes[1, 0]
    ax.plot(time, ee_rotvecs[:, 0], label='EE ωx', linewidth=2, color='red')
    ax.plot(time, ee_rotvecs[:, 1], label='EE ωy', linewidth=2, color='green')
    ax.plot(time, ee_rotvecs[:, 2], label='EE ωz', linewidth=2, color='blue')
    ax.plot(time, obj_rotvecs[:, 0], '--', color='darkred', alpha=0.7, label='Target ωx', linewidth=2)
    ax.plot(time, obj_rotvecs[:, 1], '--', color='darkgreen', alpha=0.7, label='Target ωy', linewidth=2)
    ax.plot(time, obj_rotvecs[:, 2], '--', color='darkblue', alpha=0.7, label='Target ωz', linewidth=2)
    ax.set_xlabel('Time (s)')
    ax.set_ylabel('Rotation Vector (rad)')
    ax.set_title('Rotational Response')
    ax.legend()
    ax.grid(True)
    
    # 5. EE Linear Velocities
    ax = axes[1, 1]
    ax.plot(time, data['ee_linear_velocities'][:, 0], label='Vx', linewidth=2, color='red')
    ax.plot(time, data['ee_linear_velocities'][:, 1], label='Vy', linewidth=2, color='green')
    ax.plot(time, data['ee_linear_velocities'][:, 2], label='Vz', linewidth=2, color='blue')
    # Optionally plot target velocities if available
    if 'object_linear_velocities' in data:
        ax.plot(time, data['object_linear_velocities'][:, 0], '--', color='darkred', alpha=0.7, label='Target Vx', linewidth=2)
        ax.plot(time, data['object_linear_velocities'][:, 1], '--', color='darkgreen', alpha=0.7, label='Target Vy', linewidth=2)
        ax.plot(time, data['object_linear_velocities'][:, 2], '--', color='darkblue', alpha=0.7, label='Target Vz', linewidth=2)
    ax.set_xlabel('Time (s)')
    ax.set_ylabel('Linear Velocity (m/s)')
    ax.set_title('EE Linear Velocities')
    ax.legend()
    ax.grid(True)
    
    # 6. EE Angular Velocities
    ax = axes[1, 2]
    ax.plot(time, data['ee_angular_velocities'][:, 0], label='ωx', linewidth=2, color='red')
    ax.plot(time, data['ee_angular_velocities'][:, 1], label='ωy', linewidth=2, color='green')
    ax.plot(time, data['ee_angular_velocities'][:, 2], label='ωz', linewidth=2, color='blue')
    # Optionally plot target angular velocities if available
    if 'object_angular_velocities' in data:
        ax.plot(time, data['object_angular_velocities'][:, 0], '--', color='darkred', alpha=0.7, label='Target ωx', linewidth=2)
        ax.plot(time, data['object_angular_velocities'][:, 1], '--', color='darkgreen', alpha=0.7, label='Target ωy', linewidth=2)
        ax.plot(time, data['object_angular_velocities'][:, 2], '--', color='darkblue', alpha=0.7, label='Target ωz', linewidth=2)
    ax.set_xlabel('Time (s)')
    ax.set_ylabel('Angular Velocity (rad/s)')
    ax.set_title('EE Angular Velocities')
    ax.legend()
    ax.grid(True)




    
    plt.tight_layout()
    plt.show()
    return fig
    

